#ifndef CONNECTION_HANDLER__
#define CONNECTION_HANDLER__

#include <boost/thread.hpp>  //BOOST for multiThreading
class Task{
	public:
		Task();







};
#endif
